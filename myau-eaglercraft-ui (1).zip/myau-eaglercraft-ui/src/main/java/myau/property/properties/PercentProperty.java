package myau.property.properties;

public class PercentProperty extends IntProperty {
    public PercentProperty(String name, int def) { super(name, def, 0, 100); }
    public String formatValue() { return getValue() + "%"; }
}
