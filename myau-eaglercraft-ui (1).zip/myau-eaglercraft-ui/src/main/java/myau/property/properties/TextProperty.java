package myau.property.properties;

import myau.property.Property;

public class TextProperty extends Property {
    private String value;
    public TextProperty(String name, String def) { super(name); value = def; }
    public String getValue() { return value; }
    public void setValue(String v) { value = v; }
    public String formatValue() { return value; }
}
