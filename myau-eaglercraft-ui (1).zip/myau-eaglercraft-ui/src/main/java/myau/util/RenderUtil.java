package myau.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

/** Only uses vanilla Tessellator QUADS, so it works on every Eaglercraft runtime. Has a Y clip (replaces GL scissor). */
public final class RenderUtil {
    public static float clipTop = -100000f, clipBottom = 100000f;

    private RenderUtil() {}

    public static void setClip(float top, float bottom) { clipTop = top; clipBottom = bottom; }
    public static void clearClip() { clipTop = -100000f; clipBottom = 100000f; }

    public static void drawRect(float x1, float y1, float x2, float y2, int argb) {
        if (x2 < x1) { float t = x1; x1 = x2; x2 = t; }
        if (y2 < y1) { float t = y1; y1 = y2; y2 = t; }
        y1 = Math.max(y1, clipTop);
        y2 = Math.min(y2, clipBottom);
        if (y2 <= y1 || x2 <= x1) return;
        int a = (argb >>> 24) & 255; if (a == 0) a = 255;
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, a / 255f);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION);
        wr.pos(x1, y2, 0).endVertex();
        wr.pos(x2, y2, 0).endVertex();
        wr.pos(x2, y1, 0).endVertex();
        wr.pos(x1, y1, 0).endVertex();
        t.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Rounded rect built from half-unit rows (no triangle fans needed). */
    public static void drawRoundedRect(float x, float y, float w, float h, float r, int argb) {
        r = Math.min(r, Math.min(w, h) / 2f);
        if (r <= 0.5f) { drawRect(x, y, x + w, y + h, argb); return; }
        float step = 0.5f;
        drawRect(x, y + r, x + w, y + h - r, argb);
        for (float dy = 0; dy < r; dy += step) {
            float cy = r - dy - step / 2f;
            float inset = r - (float) Math.sqrt(Math.max(0f, r * r - cy * cy));
            drawRect(x + inset, y + dy, x + w - inset, y + dy + step, argb);
            drawRect(x + inset, y + h - dy - step, x + w - inset, y + h - dy, argb);
        }
    }

    public static void drawHead(ResourceLocation skin, int x, int y, int size) {
        Minecraft.getMinecraft().getTextureManager().bindTexture(skin);
        GlStateManager.enableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        Gui.drawScaledCustomSizeModalRect(x, y, 8f, 8f, 8, 8, size, size, 64f, 64f);
        Gui.drawScaledCustomSizeModalRect(x, y, 40f, 8f, 8, 8, size, size, 64f, 64f);
        GlStateManager.disableBlend();
    }
}
